public class Spot {

    private float xCoord = 400;
    private float yCoord = 350;
    private float diameter = 100;

    public Spot() {
        xCoord = 100;
        yCoord = 200;
        diameter = 40;
    }

    public Spot(float xCoord, float yCoord, float diameter) {
        setxCoord(xCoord);
        setyCoord(yCoord);
        setDiameter(diameter);
    }

    public float getxCoord() {
        return xCoord;
    }

    public float getyCoord() {
        return yCoord;
    }

    public float getDiameter() {
        return diameter;
    }

    public void setxCoord(float xCoord) {
        if ((xCoord >= 0) && (xCoord <= 800)) {
            this.xCoord = xCoord;
        }
    }

    public void setyCoord(float yCoord) {
        if ((yCoord >= 0) && (yCoord <= 700)) {
            this.yCoord = yCoord;
        }
    }

    public void setDiameter(float diameter) {
        if ((diameter > 0) && (diameter < 600)) {
            this.diameter = diameter;
        }
    }

    public float calculateRadius(){
        return diameter/2;
    }

    public float calculateArea(){
        return 3.1415f * calculateRadius() * calculateRadius();
    }

    public float calculateCircumference() {
        return 2 * 3.1415f * calculateRadius();
    }
}


