import java.util.Scanner;

public class Driver {

    Spot spot = new Spot(40, 43, 22);
    Scanner input = new Scanner(System.in);

    public static void main(String args[]) {
        System.out.println("Spot Console V1.0");
        new Driver();
    }

    Driver(){
        addSpotDetails();
        drawSpot();
        printRadius();
        printArea();
        printCircumference();
        //update spot details and redraw spot
        updateSpotDetails();
        drawSpot();
    }

    void drawSpot(){
        printLine();
        System.out.println("xCoord:     " + spot.getxCoord());
        System.out.println("yCoord:     " + spot.getyCoord());
        System.out.println("diameter:   " + spot.getDiameter());
        printLine();
    }

    void printRadius(){
        System.out.println("radius:     " + spot.calculateRadius());
        printLine();
    }

    void printArea(){
        System.out.println("area:       " + spot.calculateArea());
        printLine();
    }

    void printCircumference(){
        System.out.println("circumference: " + spot.calculateCircumference());
        printLine();
    }

    void addSpotDetails(){
        System.out.print("Enter xCoord value: ");
        float enteredXCoord = input.nextFloat();
        System.out.print("Enter yCoord value: ");
        float enteredYCoord = input.nextFloat();
        System.out.print("Enter diameter value: ");
        float enteredDiameter = input.nextFloat();
        spot = new Spot(enteredXCoord, enteredYCoord, enteredDiameter);
    }

    void updateSpotDetails(){
        System.out.print("Enter new xCoord value: ");
        float enteredXCoord = input.nextFloat();
        System.out.print("Enter new yCoord value: ");
        float enteredYCoord = input.nextFloat();
        System.out.print("Enter new diameter value: ");
        float enteredDiameter = input.nextFloat();
        spot.setxCoord(enteredXCoord);
        spot.setyCoord(enteredYCoord);
        spot.setDiameter(enteredDiameter);
    }

    void printLine() {
        System.out.println("--------------------------" );
    }


}
