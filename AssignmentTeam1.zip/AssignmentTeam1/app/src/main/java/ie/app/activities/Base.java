package ie.app.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.List;

import ie.app.R;
import ie.app.models.Race;

public class Base extends AppCompatActivity
{
  public static List<Race> races = new ArrayList<>();

  public void newRace(Race race)
  {
      races.add(race);
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu)
  {
    getMenuInflater().inflate(R.menu.menu_race, menu);
    return true;
  }

  @Override
  public boolean onPrepareOptionsMenu (Menu menu){
    super.onPrepareOptionsMenu(menu);
    MenuItem report = menu.findItem(R.id.menuReport);
    MenuItem addrace = menu.findItem(R.id.menuAddRace);

    if(races.isEmpty())
      report.setEnabled(false);
    else
      report.setEnabled(true);

    if(this instanceof AddRace){
      addrace.setVisible(false);
      if(!races.isEmpty())
        report.setVisible(true);
    }
    else {
      report.setVisible(false);
      addrace.setVisible(true);
    }

    return true;
  }


  public void report(MenuItem item)
  {
    startActivity (new Intent(this, Report.class));
  }

  public void addrace(MenuItem item)
  {
    startActivity (new Intent(this, AddRace.class));
  }
}