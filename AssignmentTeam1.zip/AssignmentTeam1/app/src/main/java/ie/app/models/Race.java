package ie.app.models;

public class Race {

  public String name;
  public int hours;
  public int minutes;

  public Race(String name, int hours, int minutes) {
    this.name = name;
    this.hours = hours;
    this.minutes = minutes;
  }


  @Override
  public String toString() {
    return "Race{" +
        "name='" + name + '\'' +
        ", hours=" + hours +
        ", minutes=" + minutes +
        '}';
  }
}
