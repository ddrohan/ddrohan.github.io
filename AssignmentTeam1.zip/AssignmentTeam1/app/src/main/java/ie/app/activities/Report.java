package ie.app.activities;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import ie.app.R;
import ie.app.models.Race;

public class Report extends Base
{
    ListView listView;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.race_report);

        listView = findViewById(R.id.reportList);
        RaceAdapter adapter = new RaceAdapter(this, races);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(Report.this,
                               "Donation Data : " + races.get(position),
                                Toast.LENGTH_LONG)
                                .show();
            }
        });
    }
}

class RaceAdapter extends ArrayAdapter<Race>
{
    private Context context;
    public List<Race> races;

    public RaceAdapter(Context context, List<Race> races)
    {
        super(context, R.layout.race_row, races);
        this.context   = context;
        this.races = races;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View     view       = inflater.inflate(R.layout.race_row, parent, false);
        Race race   = races.get(position);
        TextView racetypeView = view.findViewById(R.id.row_racetype);
        TextView hoursView = view.findViewById(R.id.row_hours);

        racetypeView.setText(race.name);
        hoursView.setText(race.hours + " Hrs");


        return view;
    }

    @Override
    public int getCount()
    {
        return races.size();
    }
}