package ie.app.activities;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.Toast;

import ie.app.R;
import ie.app.models.Race;

public class AddRace extends Base {

    private Button          addRaceButton;
    private RadioGroup      raceType;
    private NumberPicker    hourPicker;
    private NumberPicker    minutePicker;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_race);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
            }
        });

        addRaceButton = findViewById(R.id.addRaceButton);
        raceType =      findViewById(R.id.raceType);
        hourPicker =    findViewById(R.id.hourPicker);
        minutePicker =    findViewById(R.id.minutePicker);

        hourPicker.setMinValue(0);
        hourPicker.setMaxValue(24);

        minutePicker.setMinValue(0);
        minutePicker.setMaxValue(59);

    }

    public void addRaceButtonPressed(View view)
    {
        String racetype = "";

        int raceTypeID = raceType.getCheckedRadioButtonId();

        if(raceTypeID == R.id.Swim) {
            racetype = "Swim";
        }
        else if(raceTypeID == R.id.Cycle) {
            racetype = "Cycle";
        }
        else if(raceTypeID == R.id.Run) {
            racetype = "Run";
        }

        int hours =  hourPicker.getValue();

        int minutes =  minutePicker.getValue();

        if (hours == 0)
        {
            Toast.makeText(this, "Please Enter a Value for Hours!! ",Toast.LENGTH_LONG).show();
        }
        else if (hours > 0)
        {
            newRace(new Race(racetype, hours, minutes));

            Log.v("Races","Current Race List is : " + races);

        }
    }
}